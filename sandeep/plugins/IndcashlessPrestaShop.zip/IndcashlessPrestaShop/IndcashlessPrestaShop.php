<?php
if (!defined('_PS_VERSION_'))
	exit;

class IndcashlessPrestaShop extends PaymentModule
{
	private $error_messages;
	public function __construct()
	{
		$this->name = 'IndcashlessPrestaShop';
		$this->tab = 'payments_gateways';
		$this->version = '1.0.1';
		$this->author = 'D';
		$this->need_instance = 0;
		$this->controllers = array('validation');
		$this->is_eu_compatible = 1;
		$this->error_messages;
		$this->bootstrap = true;
		$this->currencies = true;
		$this->currencies_mode = 'checkbox';
 
		parent::__construct();

		$this->displayName = $this->l('Indcashless');
		$this->description = $this->l('Accept Online payments');

		/* For 1.4.3 and less compatibility */
		$updateConfig = array('PS_OS_CHEQUE', 'PS_OS_PAYMENT', 'PS_OS_PREPARATION', 'PS_OS_SHIPPING', 'PS_OS_CANCELED', 'PS_OS_REFUND', 'PS_OS_ERROR', 'PS_OS_OUTOFSTOCK', 'PS_OS_BANKWIRE', 'PS_OS_PAYPAL', 'PS_OS_WS_PAYMENT');
		if (!Configuration::get('PS_OS_PAYMENT'))
			foreach ($updateConfig as $u)
				if (!Configuration::get($u) && defined('_'.$u.'_'))
					Configuration::updateValue($u, constant('_'.$u.'_'));
		
		/* Check if cURL is enabled */
		if (!is_callable('curl_exec'))
			$this->warning = $this->l('cURL extension must be enabled on your server to use this module.');
		
	}

	public function install()
	{
		parent::install();
		$this->registerHook('payment');
		$this->registerHook('displayPaymentEU');
		$this->registerHook('paymentReturn');
		Configuration::updateValue('indcashless_checkout_label', 'Credit Card(Visa/MasterCard) with Indcashless');
		return true;
	}
	
	
	public function uninstall()
	{
		  parent::uninstall();
		  Configuration::deleteByName('transaction_url');
		  Configuration::deleteByName('indcashless_public_key');
		  Configuration::deleteByName('indcashless_terNO');
		  Configuration::deleteByName('indcashless_testmode');
		  Configuration::deleteByName('indcashless_checkout_label');
		  Configuration::deleteByName('billing_address');
		return true;
	}
	public function hookPayment()
	{
		if (!$this->active)
			return ;
		
		$this->smarty->assign(array(
			'this_path' => $this->_path, //keep for retro compat
			'this_path_indcashless' => $this->_path,
			'checkout_label' => $this->l((Configuration::get('indcashless_checkout_label')) ? Configuration::get('indcashless_checkout_label'): "Credit Card(Visa/MasterCard) with Indcashless"),
			'billing_address' => $this->l((Configuration::get('billing_address'))),
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/' . $this->name . '/'
		));
		
		return $this->display(__FILE__, 'payment.tpl');
	}
	
	public function hookDisplayPaymentEU()
	{
		if (!$this->active){
			return ;
		}
		
		return array(
			'cta_text' => $this->l((Configuration::get('indcashless_checkout_label'))?Configuration::get('indcashless_checkout_label'):"Credit Card(Visa/MasterCard) with Indcashless"),
			//'cta_text' =>$this->l((Configuration::get('billing_address'))),
			'logo' => Media::getMediaPath(dirname(__FILE__).'/visamastjcb.jpg'),
			'action' => $this->context->link->getModuleLink($this->name, 'validation', array('confirm' => true), true),
			'additionalInformation'=>$this->context->smarty->fetch('module:IndcashlessPrestaShop/views/templates/front/billing_discription.tpl')
				
		); 
		
	}
	
	
	public function getIndcashlessObject($logger){
		include_once __DIR__. DIRECTORY_SEPARATOR . "lib/indcashless.php";
		$credentials = $this->getConfigValues();
		$logger->logDebug("Transaction URL: $credentials[transaction_url] Store PUBLIC KEY : $credentials[indcashless_public_key] BUSINESS TerNO : $credentials[indcashless_terNO] TestMode : $credentials[indcashless_testmode] ");
		//$api  = new IndcashlessApi($credentials['transaction_url'],$credentials['indcashless_public_key'],$credentials['indcashless_terNO'],$credentials['indcashless_testmode']);
		//return $api;
		return $credentials;
	}
	
	public function hookPaymentReturn()
	{
		if (!$this->active)
			return ;
		return ;
	}
	
	public function getConfigValues(){
		
		$data = array();
		$data['transaction_url'] = Configuration::get('transaction_url');
		$data['indcashless_public_key'] = Configuration::get('indcashless_public_key');
		$data['indcashless_terNO'] = Configuration::get('indcashless_terNO');
		$data['indcashless_testmode'] = Configuration::get('indcashless_testmode');
		$data['indcashless_checkout_label'] = Configuration::get('indcashless_checkout_label');
		$data['billing_address'] = Configuration::get('billing_address');
		return $data;
	}
	
	
	public function validate_data(){
		$this->error_messages = "";

		if(!strval(Tools::getValue('transaction_url')))
			$this->error_messages .= "Transaction URL is Required<br/>";
		if(!strval(Tools::getValue('indcashless_public_key')))
			$this->error_messages .= "Indcashless Store PUBLIC KEY is Required<br/>";
		if(!strval(Tools::getValue('indcashless_terNO')))
			$this->error_messages .= "BUSINESS TerNO is Required<br/>";
		if(!strval(Tools::getValue('billing_address')))
			$this->error_messages .= "Billing Address is Required<br/>";		
		return !$this->error_messages;
	}
	
	# Show Configuration form in admin panel.
	public function getContent()
	{
		$output = null;
		// $order_states = OrderState::getOrderStates((int)$this->context->cookie->id_lang);
		if (Tools::isSubmit('submit'.$this->name))
		{
			$data = array(); 
			$data['transaction_url'] = strval(Tools::getValue('transaction_url'));
			$data['indcashless_public_key'] = strval(Tools::getValue('indcashless_public_key'));
			$data['indcashless_terNO'] = strval(Tools::getValue('indcashless_terNO'));
			$data['indcashless_testmode'] = strval(Tools::getValue('indcashless_testmode'));
			$data['indcashless_checkout_label'] = strval(Tools::getValue('indcashless_checkout_label'));
			$data['billing_address'] = strval(Tools::getValue('billing_address'));
			
			
			if ($this->validate_data($data))
			{
				Configuration::updateValue('transaction_url', $data['transaction_url']);
				Configuration::updateValue('indcashless_public_key', $data['indcashless_public_key']);
				Configuration::updateValue('indcashless_terNO', $data['indcashless_terNO']);
				Configuration::updateValue('indcashless_testmode', $data['indcashless_testmode']);
				Configuration::updateValue('indcashless_checkout_label', $data['indcashless_checkout_label']);
				Configuration::updateValue('billing_address', $data['billing_address']);
				$output .= $this->displayConfirmation($this->l('Settings updated'));
			}else
				$output .= $this->displayError($this->error_messages);
		}
		return $output.$this->displayForm();
	}
	
	public function displayForm()
	{
		// Get default language
		$default_lang = (int)Configuration::get('PS_LANG_DEFAULT');
		 
		// Init Fields form array
		$fields_form =array();
		$fields_form[0]['form'] = array(
			'legend' => array(
				'title' => $this->l('Settings'),
			),
			'input' => array(
					array(
					'type' => 'text',
					'label' => $this->l('Checkout Label'),
					'name' => 'indcashless_checkout_label',
			 		'required' => true
				),
				array(
					'type' => 'text',
					'label' => $this->l('Billing Address'),
					'name' => 'billing_address',
			 		'required' => true
				),
				array(
					'type' => 'text',
					'label' => $this->l('Transaction URL'),
					'name' => 'transaction_url',
					'required' => true
				),
			
			
				array(
					'type' => 'text',
					'label' => $this->l('Store PUBLIC KEY'),
					'name' => 'indcashless_public_key',
					'required' => true
				),
				
				array(
					'type' => 'text',
					'label' => $this->l('BUSINESS TerNO'),
					'name' => 'indcashless_terNO',
					'required' => true
				),
			
				array(
				  'type'      => 'radio',                      
				  'label'     => $this->l('Test Mode'),        
				  'name'      => 'indcashless_testmode',				  
				  'required'  => true,                         
				  'is_bool'   => true,                         
				  'values'    => array(                        
					array(
					  'id'    => 'active_on',                  
					  'value' => 1,                               
					  'label' => $this->l('Enabled')           
					),
					array(
					  'id'    => 'active_off',
					  'value' => 0,
					  'label' => $this->l('Disabled')
					)
				  ),
				)
			),
			
			'submit' => array(
				'title' => $this->l('Save'),
				'class' => 'btn btn-default pull-right'
			)
		);
		 
		$helper = new HelperForm();
		 
		// Module, token and currentIndex
		$helper->module = $this;
		$helper->name_controller = $this->name;
		$helper->token = Tools::getAdminTokenLite('AdminModules');
		$helper->currentIndex = AdminController::$currentIndex.'&configure='.$this->name;
		 
		// Language
		$helper->default_form_language = $default_lang;
		$helper->allow_employee_form_lang = $default_lang;
		 
		// Title and toolbar
		$helper->title = $this->displayName;
		$helper->show_toolbar = true;        // false -> remove toolbar
		$helper->toolbar_scroll = true;      // yes - > Toolbar is always visible on the top of the screen.
		$helper->submit_action = 'submit'.$this->name;
		
		 
		// Load current value
		$helper->fields_value = $this->getConfigValues();
		 
		return $helper->generateForm($fields_form);
	}
}
