<?php
error_reporting(-1);
function is_not_17(){
	return version_compare(_PS_VERSION_, '1.7', '<');
}

class IndcashlessPrestaShopValidationModuleFrontController extends ModuleFrontController
{
	public $ssl = true;
	private $template_data =array();
	public $display_column_left = false;

	public function postProcess()
	{
		if ($this->context->cart->id_customer == 0 || $this->context->cart->id_address_delivery == 0 || $this->context->cart->id_address_invoice == 0 || !$this->module->active){
			Tools::redirectLink(__PS_BASE_URI__.'order.php?step=1');
		}
		$customer = new Customer($this->context->cart->id_customer);
		if (!Validate::isLoadedObject($customer)){
			Tools::redirectLink(__PS_BASE_URI__.'order.php?step=1');
		}
		
		$customer = new Customer((int)$this->context->cart->id_customer);
        $total = $this->context->cart->getOrderTotal(true, Cart::BOTH);
        $this->module->validateOrder((int)$this->context->cart->id, Configuration::get('PS_OS_PREPARATION'), $total, $this->module->displayName, null, array(), null, false, $customer->secure_key);
       
		
		$method_data = array();
		if (Tools::getValue('confirm') or Tools::getValue('updatePhone') )
		{
			# prepare some object to fetch necessary information.
			$customer = new Customer((int)$this->context->cart->id_customer);
			$address = new Address((int)$this->context->cart->id_address_invoice);
			$total = $this->context->cart->getOrderTotal(true, Cart::BOTH);

			# update phone.
			if(Tools::getValue('updatePhone')){
				$address->phone_mobile = Tools::getValue("mobile");
				$address->save();
			}
			
			# prepare logger
			$logger = new FileLogger(0); //0 == debug level, logDebug() won’t work without this.
			if (is_not_17()){
				$logger->setFilename(_PS_ROOT_DIR_ . "/log/indcashless.log");
			}
			else{
				$logger->setFilename(_PS_ROOT_DIR_ . "/app/logs/indcashless.log");
			}
			$logger->logDebug("Creating Indcashless order for  ".$this->context->cart->id);
			
			# prepare data
			$api_data = Array();
			$api_data['name'] 			= Tools::substr(trim((html_entity_decode($customer->firstname . ' ' . $customer->lastname, ENT_QUOTES, 'UTF-8'))), 0, 20);
			$api_data['bill_email'] 			= Tools::substr($customer->email, 0, 75);
			$api_data['bill_amt'] 		= $total;
			//$api_data['currency'] 	= "INR";
			$api_data['bill_currency'] 		= $currency->iso_code;
			$api_data['redirect_url'] 	= $this->context->link->getModuleLink($this->module->name, 'confirm', array(), true);
			$api_data['transID'] = time()."-".$this->context->cart->id;
			
			if($address->phone_mobile)
				$phone = $address->phone_mobile;
			else
				$phone = $address->phone;
			
			$api_data['phone']=$phone;
			
			$currency = $this->context->currency;
			
			$adminConfig = $this->module->getIndcashlessObject($logger);
			
			$postData = Array();
			
			$transaction_url =$adminConfig['transaction_url'];
			
			$postData['public_key'] =$adminConfig['indcashless_public_key'];
			$postData['terNO'] =$adminConfig['indcashless_terNO'];
			
			$postData['integration-type'] ="Encode-Checkout";
			$postData['action'] ="product";
			$postData['mode'] ="live";
			$postData['bill_amt'] =$total;
			$postData['bill_currency'] =$currency->iso_code;
			$postData['fullname'] =($customer->firstname." ".$customer->lastname);
			$postData['bill_name'] =Tools::substr(trim((html_entity_decode($customer->firstname . ' ' . $customer->lastname, ENT_QUOTES, 'UTF-8'))), 0, 20);
			$postData['bill_email'] =Tools::substr($customer->email, 0, 75);
			$postData['bill_phone'] =$phone;
			
			$bill_address = ($address->address1) . " " .($address->address2);
			
			$postData['bill_address'] =$bill_address;
			
			$postData['bill_city'] =($address->city);
			$postData['bill_state'] =(State::getNameById($address->id_state));
			$postData['bill_zip'] =($address->postcode);
			$postData['bill_country'] =($address->country);
			$id_cart =$this->context->cart->id;
			$postData['id_cart'] =((int)$this->module->currentOrder);
			$postData['reference'] =$id_cart;
			//$postData['reference'] =((int)$this->module->currentOrder);
			
			$postData['source'] ="prestashop 1.7.3 ReDirect";
			$postData['webhook_url'] =$this->context->link->getModuleLink($this->module->name, 'confirm', array(), true);
			$postData['return_url'] =$this->context->link->getModuleLink($this->module->name, 'success', array(), true);
			//$postData['error_url'] =$this->context->link->getModuleLink($this->module->name, 'failed', array(), true);
			
			$products = Context::getContext()->cart->getProducts();
			$product_name = array();
			foreach ($products as $product) 
			{
			  $product_name[] = (int)$product['name'];
			  
			}			
			
			$postData['product_name'] =implode(",",$product_name);
			
			
			try{
				
				
				$logger->logDebug("Data sent for creating order ".print_r($postData,true));
				
				$postData_get=http_build_query($postData);
				
				header("location:$transaction_url?$postData_get");
				
				
				
			}catch(CurlException $e){
				// handle exception releted to connection to the sever
				$logger->logDebug((string)$e);
				$method_data['api_errors'][] = $e->getMessage();
			}catch(ValidationException $e){
				// handle exceptions releted to response from the server.
				$logger->logDebug($e->getMessage()." with ");
				$logger->logDebug(print_r($e->getResponse(),true)."");
				$method_data['api_errors'] = $e->getErrors();			
			}catch(Exception $e)
			{ // handled common exception messages which will not caught above.
				$method_data['api_errors'][] = $e->getMessage();
				$logger->logDebug('Error While Creating Order : ' . $e->getMessage());
			}
			
			$this->template_data = $method_data;
			$this->template_data['mobile'] = $api_data['phone'];
			
			# check if phone input box should b displayed or not
			if(isset($method_data['api_errors'])):
				foreach($method_data['api_errors'] as $e)
				{
					if(stristr($e,"phone")){
						$this->template_data['showPhoneBox']=1;
						break;
					}
				}
			endif;
		}
	}

	/**
	 * @see FrontController::initContent()
	 */
	public function initContent()
	{
		
		$temp_data = array(
			'total' => $this->context->cart->getOrderTotal(true, Cart::BOTH),
			'this_path' => $this->module->getPathUri(), //keep for retro compat
			'checkout_label' => Configuration::get('indcashless_checkout_label'),
			'this_path_indcashless' => $this->module->getPathUri(),
			'this_path_ssl' => Tools::getShopDomainSsl(true, true).__PS_BASE_URI__.'modules/'.$this->module->name.'/',
		);
		$this->template_data = array_merge($this->template_data, $temp_data);
		$this->context->smarty->assign($this->template_data);
		$this->display_column_left = false;
		$this->display_column_right = false;
		if(is_not_17()){
			$this->setTemplate('validation_old.tpl');
		}
		else{
			$this->setTemplate('module:IndcashlessPrestaShop/views/templates/front/validation_new.tpl');
		}
		parent::initContent();
	}
}
