<?php
exit;
class IndcashlessPrestaShopConfirmModuleFrontController extends ModuleFrontController
{
	public function initContent()
	{
		# prepare logger.
		$logger = new FileLogger(0); //0 == debug level, logDebug() won’t work without this.
		if (version_compare(_PS_VERSION_, '1.7', '<')){
			$logger->setFilename(_PS_ROOT_DIR_ . "/log/indcashless.log");
		}
		else{
			$logger->setFilename(_PS_ROOT_DIR_ . "/app/logs/indcashless.log");
		}
		
		$base_url = _PS_BASE_URL_.__PS_BASE_URI__;
		
		
			
			try{
				/*
				$api = $this->module->getIndcashlessObject($logger);
				$response = $api->getOrderById($payment_request_id);
				$logger->logDebug("Response from server for PaymentRequest ID $payment_request_id ".PHP_EOL .print_R($response,true));
				$payment_status = $api->getPaymentStatus($transID, $response->payments);
				*/
		        
				
				$payment_status="";$transID="";$reference="";$amount="";$bill_currency="";$p=array();
		
				if($_POST){
					$p=$_POST;
					$payment_status=$_POST['status'];
					$order_status=(int)$_POST['order_status'];
					$transID=$_POST['transID'];
					$reference = $_POST['reference'];
					$amount = $_POST['bill_amt'];
					$bill_currency = $_POST['bill_currency'];
				}
				else if($_GET){
					$p=$_GET;
					$payment_status=$_GET['status'];
					$order_status=(int)$_GET['order_status'];
					$transID=$_GET['transID'];
					$reference = $_GET['reference'];
					$amount = $_GET['bill_amt'];
					$bill_currency = $_GET['bill_currency'];
				}
				
				if(($reference) && (strpos($reference,"-")!==false)){
					$reference = explode("-",$reference);
					$reference = $reference[1];
					$logger->logDebug("Extracted order id from order_id: ".$reference);
				}
				
				
				echo "<hr/>reference=> ".$transID;
				echo "<hr/>payment_request_id=> ".$payment_request_id;
				echo "<hr/>payment_status=> ".$payment_status;
				echo "<hr/>order_status=> ".$order_status;
				echo "<hr/>transID=> ".$transID;
				echo "<hr/>reference=> ".$id_cart;
				
				exit;
				
				
				$logger->logDebug("Payment status for $transID is $payment_status");

				if($payment_status)
				{
					$logger->logDebug("Response from server is $payment_status.");
					
					
					$order_id = $reference;
					
					$logger->logDebug("Extracted order id from trasaction_id: ".$order_id);
					
					if($this->context->cart->id != $order_id)
					{
						$logger->logDebug("Cart ID sent to Indcashless ($order_id) doesn't match with current cart id (".$this->context->cart->id.")");
						Tools::redirectLink($this->context->link->getPageLink('order',true)."?step=1");
					}
					
					$extra_vars = Array(); 
					$extra_vars['transID'] = $transID;
					$customer = new Customer($this->context->cart->id_customer);
					$total = $this->context->cart->getOrderTotal(true, Cart::BOTH);

					if($order_status == 1 || $order_status == 9){ // 1:Approved/Success,9:Test Transaction
					  $logger->logDebug("Payment for $transID was credited.");
					  $this->module->validateOrder($this->context->cart->id , _PS_OS_PAYMENT_, $total, Configuration::get('indcashless_checkout_label'), NULL, $extra_vars, NULL, false, $customer->secure_key, NULL);
					  
					  //Tools::redirectLink(__PS_BASE_URI__.'index.php?controller=order-detail&reference='.(int)$this->module->currentOrder);
					}
					else if($order_status == 2 || $order_status == 22 || $order_status == 23){ // 2:Declined/Failed, 22:Expired, 23:Cancelled
					  $logger->logDebug("Payment for $transID failed.");
					  $cart_id = $this->context->cart->id;
					  $this->module->validateOrder($this->context->cart->id , _PS_OS_ERROR_, $total, Configuration::get('indcashless_checkout_label'), NULL, $extra_vars, NULL, false, $customer->secure_key, NULL);
					 
					 // $this->context->cart = new Cart($cart_id);
					  //$duplicated_cart = $this->context->cart->duplicate();
					  //$this->context->cart = $duplicated_cart['cart'];
					  //$this->context->cookie->id_cart = (int)$this->context->cart->id;
					  
					  //Tools::redirectLink($this->context->link->getPageLink('order',true));

					}
					
				}
			}catch(CurlException $e){
				$logger->logDebug($e);
				//Tools::redirectLink($base_url);
			}catch(Exception $e){
				$logger->logDebug($e->getMessage());
				$logger->logDebug("Payment for $transID was not credited.");
				//Tools::redirectLink($base_url);
			}							
		else
		{
			$logger->logDebug("Callback called with no payment ID or payment_request Id.");
			//Tools::redirectLink($base_url);
		}	
	}
}
