<?php
class IndcashlessPrestaShopSuccessModuleFrontController extends ModuleFrontController
{
   
	public function initContent()
	{	
		//session_start();
		
	try{
		
		$q=0;
		if(isset($_REQUEST['q'])&&$_REQUEST['q']){
			$q=1;
		}
		if($q){
			print_r($_REQUEST);
		}
		
		$transactionId = $_REQUEST['transID'];
		$bill_amt=$_REQUEST['bill_amt'];
		$cartId = $_REQUEST['reference'];
		
		// check if a order already present for this cart
        $cart = new Cart($cartId);
		$id_cart=$cart->id;
        // Fetch the Order ID of this CartId
        $orderId = Order::getOrderByCartId($cart->id);

        // If order associated with the cart
        if(!empty($orderId))
        {
            $order = new Order($orderId);
			
			if($q){
				echo "<br/><br/>cart id=>". $id_cart;
				echo "<br/><br/>order id=>". $orderId;
				echo "<br/><br/>order=>";print_r($order);
			}

            // If payment is already done, ignore the event
            $payments = $order->getOrderPayments();
			
			if(!empty($payments))
			{
				$payments_id=$payments[0]->id;
				$order_reference=$payments[0]->order_reference;
				
				if($q){
					echo "<br/><br/>id=>".$payments_id;
					echo "<br/><br/>order_reference=>".$order_reference;
					echo "<br/><br/>payments=>";print_r($payments);
				}
				
				$transID_status=$_REQUEST['transID']. " - " .$_REQUEST['status'];
				$card_number=((isset($_REQUEST['ccno'])&&$_REQUEST['ccno'])?$_REQUEST['ccno']:'');
				$card_brand=((isset($_REQUEST['cardtype'])&&$_REQUEST['cardtype'])?$_REQUEST['cardtype']:'');
				$card_holder=((isset($_REQUEST['fullname'])&&$_REQUEST['fullname'])?$_REQUEST['fullname']:'');
				
				$db = Db::getInstance();
				$request1 = "UPDATE `" . _DB_PREFIX_ . "order_payment` SET `transID`='{$transID_status}', `card_number`='{$card_number}', `card_brand`='{$card_brand}', `card_holder`='{$card_holder}'  WHERE `id_order_payment` = '{$payments_id}' ";
				
				if($q){
					echo "<br/><br/>request1=>".$request1;
				}
				$result1 = $db->execute($request1);
			}

            if (count($payments) >= 1)
            {
                //exit;
            }

          

            try
            {
                $order->setCurrentState((int) Configuration::get('PS_OS_PAYMENT'));
            }
            catch (Exception $e)
            {
                $error = $e->getMessage();

                Logger::addLog("Payment Failed for Order# ".$cart->id.". Indcashless payment id: ".$transactionId. "Error: ". $error, 1);

                echo 'Order Id: '.$order->id_cart.'</br>';
                echo 'Indcashless Payment Id: '.$transactionId.'</br>';
                echo 'Error: '.$error.'</br>';

                exit;
            }
           // exit;
        }
		
		$customer = new Customer($cart->id_customer);
		 
		if($q){
			echo "<br/><br/>customer=>";print_r($customer);
			
			echo "<br/><br/>confirmation=>".(__PS_BASE_URI__.'order-confirmation.php?key='.$customer->secure_key.'&id_cart='.(int)$id_cart.'&id_module='.(int)$this->module->id.'&reference='.(int)$orderId);
			
			exit;
		}
		
		Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?key='.$customer->secure_key.'&id_cart='.(int)$id_cart.'&id_module='.(int)$this->module->id.'&reference='.(int)$orderId);
		
		
	}catch (Exception $e)
	{
		
		
		$method_data['api_errors'][] = $e->getMessage();
		$logger->logDebug('Error While Creating Order : ' . $e->getMessage());

	
		//exit;
	}
	}
}