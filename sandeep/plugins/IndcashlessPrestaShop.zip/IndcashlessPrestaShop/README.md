# Indcashless Prestashop Payment Gateway Plugin

Tested on PrestaShop 1.5+ to 1.7.1.1

## Installation

#### Automatic Installation

1. Go to "Modules and Services" from Main menu.
2. Click on "Add a new module".
3. Now click on zip file you had downloaded earlier and upload it.
4. Now search for Indcashless in your plugins and click on "Install" button corresponding to Indcashless module.

#### Manual Installation:

1. Extract the zip file in your in `modules` directory in your PrestaShop installation directory.
4. Now search for Indcashless in your plugins and click on "Install" button corresponding to Indcashless module.

## Configuration

1. After installation click on "Configure" button corresponding to Indcashless module.
2. Fill the following details:

    -  **Checkout Label:** This is the label users will see during checkout, its default value is "Credit Card(Visa/MasterCard) with Indcashless". You can change it to something more generic like "Pay using Credit/Debit Card or Online Banking".
     
    - **Transaction URL** and **Store PUBLIC KEY** - Store PUBLIC KEY and Transaction URL can be generated on the [Integrations page]received the transaction url. 
    
    - **Test Mode:** If enabled you can use our [Sandbox environment]received the transaction url to test payments. Note that in this case you should use `Store PUBLIC KEY` and `Transaction URL` from the test account not production.

## Migrating from older version(version < 2.0.0)

If you were already using older version of our plugin then follow these steps:

1. Go to "Modules and Services" from Main menu.
2. Now search for Indcashless in your plugins and click on "Uninstall" button corresponding to Indcashless module and then click on "Delete" to remove it.
3. You might want to clear the cache by going to `Advanced Parameters` -> `Performance`.

## Support

For any issue send us an email to support team and share the `indcashless.log` file. 

The location of `indcashless.log` file:
  - 1.7+ -> `app/logs/indcashless.log`
  - <= 1.6 -> `log/indcashless.log`
 