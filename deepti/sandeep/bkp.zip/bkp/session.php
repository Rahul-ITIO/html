<?php
    header('Content-Type: text/plain');
    session_start();
    if(!isset($_SESSION['visit']))
    {
        echo "This is the first time you're visiting this server\n";
        $_SESSION['visit'] = 0;
    }
    else
            echo "Your number of visits: ".$_SESSION['visit'] . "\n";

    $_SESSION['visit']++;

    echo "Server IP: ".$_SERVER['SERVER_ADDR'] . "\n";
    echo "Client IP: ".$_SERVER['REMOTE_ADDR'] . "\n";
    
	echo "HTTP_CLIENT_IP: ". $_SERVER['HTTP_CLIENT_IP'] . "\n";
    echo "HTTP_X_FORWARDED_FOR: ". $_SERVER['HTTP_X_FORWARDED_FOR'] . "\n";
    print_r($_COOKIE);

    $remote  = $_SERVER['REMOTE_ADDR'];

    if(filter_var($client, FILTER_VALIDATE_IP))
    {
        $ip = $client;
    }
    elseif(filter_var($forward, FILTER_VALIDATE_IP))
    {
        $ip = $forward;
    }
    else
    {
        $ip = $remote;
    }
   echo "Remote Client IP: ".$ip . "\n";

    $ipaddress = '';
      if (getenv('HTTP_CLIENT_IP'))
          $ipaddress = getenv('HTTP_CLIENT_IP');
      else if(getenv('HTTP_X_FORWARDED_FOR'))
          $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
      else if(getenv('HTTP_X_FORWARDED'))
          $ipaddress = getenv('HTTP_X_FORWARDED');
      else if(getenv('HTTP_FORWARDED_FOR'))
          $ipaddress = getenv('HTTP_FORWARDED_FOR');
      else if(getenv('HTTP_FORWARDED'))
          $ipaddress = getenv('HTTP_FORWARDED');
      else if(getenv('REMOTE_ADDR'))
          $ipaddress = getenv('REMOTE_ADDR');
      else
              $ipaddress = 'UNKNOWN';
    echo "2 Remote Client IP: ".$ipaddress . "\n";

    echo "3 Remote Client IP: ".($_SERVER['HTTP_X_FORWARDED_FOR']?:$_SERVER['HTTP_CLIENT_IP']). "\n";
    
	echo "4 Remote Client IP: ".($_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR']). "\n\n";
	echo "HTTPS: ".($_SERVER["HTTPS"]). "\n";
	echo "HTTP_HOST: ".($_SERVER["HTTP_HOST"]). "\n";
	echo "SERVER_NAME: ".($_SERVER["SERVER_NAME"]). "\n";
?>