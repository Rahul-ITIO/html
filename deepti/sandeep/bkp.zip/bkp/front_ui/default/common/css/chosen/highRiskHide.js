document.getElementById('navbarmain').style.display='none';
document.getElementById('tranStatDIVbar').style.display='none';