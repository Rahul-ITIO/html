<?php
$response = '[
{
	"address": "TMPkaVjxeQYGa2NANHGaryMg51gczcXb4K",
	"amount": "200",
	"applyTime": "2021-09-12 11:12:02",
	"coin": "USDT",
	"id": "eceb8449fa124e64bb9cdc9e9aa5c133",
	"withdrawOrderId": "WITHDRAWtest123",
	"network": "TRX", 
	"transferType": 0,
	"status": 6,
	"transactionFee": "0.004",
	"confirmNo":3,
	"txId": "0xb5ef8c13b968a406cc62a93a8bd80f9e9a906ef1b3fcf20a2e48573c17659268"
},
{
	"address": "TMPkaVjxeQYGa2NANHGaryMg51gczcXb4K",
	"amount": "0.00150000",
	"applyTime": "2019-09-24 12:43:45",
	"coin": "BTC",
	"id": "156ec387f49b41df8724fa744fa82719",
	"network": "TRX",
	"status": 6,
	"transactionFee": "0.004",
	"transferType": 0,
	"confirmNo":2,
	"txId": "60fd9007ebfddc753455f95fafa808c4302c836e4d1eebc5a132c36c1d8ac354"
}
]';
?>