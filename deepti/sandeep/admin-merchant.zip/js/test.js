$(document).ready(function(){
	//120000 (60000 x 2=120000) 2 minutes
	
	//alert("OK1==");
	/*
	setTimeout( function(){ 
		//alert("OK==");
		top.document.location.href=window.document.location.href;
	}, 900000 );
	*/
	/*setInterval( function(){ 
		alert("OK3==");
		//top.document.location.href=window.document.location.href;
	}, 1000 );
	*/
	
	

});