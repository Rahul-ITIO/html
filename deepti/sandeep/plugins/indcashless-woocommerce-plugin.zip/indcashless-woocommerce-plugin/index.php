<?php 


/*
Plugin Name: Ind Cashless Payment Gateway for WooCommerce
Plugin URI: 
Description: WooCommerce with indcashless payment gateway.
Version: 1.3

*/
include_once('woo-check-card-class.php');
if (!defined('ABSPATH'))
    exit;
add_action('plugins_loaded', 'woocommerce_indcashless_init', 0);
function woocommerce_indcashless_init()
{
    if (!class_exists('WC_Payment_Gateway'))
        return;
    /**
     * Gateway class
     */
     
 
     
    class WC_indcashless extends WC_Payment_Gateway
    {
        
        public function __construct()
        {
            // Go wild in here
            $this->id           = 'indcashless';
            $this->method_title = __('IndCashLess');
            $this->has_fields   = true;
            $this->init_form_fields();
            $this->init_settings();
          
		  
		  
		   if ($this->settings['logo']=="yes"){			
				$this->icon = woocommerce_plugin_url_indcashless . '/img/visamastjcb.png';
			}
			
			
			
			$this->title            = $this->settings['title'];
			
			$this->description      = $this->settings['description'];
			
            $this->public_key        = $this->settings['public_key'];
            $this->terNO         = $this->settings['terNO'];
            
            $this->transaction_url        = $this->settings['transaction_url'];
            
            $this->indcashless_type   = $this->settings['indcashless_type'];
            $this->status_completed = $this->settings['status_completed'];
            $this->status_cancelled = $this->settings['status_cancelled'];
            $this->status_pending   = $this->settings['status_pending'];
            $this->checkout_language   = $this->settings['checkout_language'];
            $this->webhook_url       = home_url('/wc-api/WC_indcashless');
            $this->msg['message']   = "";
            $this->msg['class']     = "";
          //  add_action('woocommerce_api_wc_tasaction_status', array(  $this, 'check_trasaction'));
            
            
            add_action('woocommerce_api_wc_indcashless', array(
                $this,
                'check_indcashless_response'
            ));
            
            add_action('valid-indcashless-request', array(
                $this,
                'successful_request'
            ));
			
            add_action( 'wp_enqueue_scripts', array( $this, 'payment_scripts' ) );
			
			add_action( 'admin_enqueue_scripts', 'admin_indcashless_load_scripts' );
            
           
            
            
            if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {
                add_action('woocommerce_update_options_payment_gateways_' . $this->id, array(
                    $this,
                    'process_admin_options'
                ));
            } else {
                add_action('woocommerce_update_options_payment_gateways', array(
                    &$this,
                    'process_admin_options'
                ));
            }
            add_action('woocommerce_receipt_indcashless', array(
                $this,
                'receipt_page'
            ));
        }
        

        
        function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', ''),
                    'type' => 'checkbox',
                    'label' => __('Payment Module.', ''),
                    'default' => 'no'
                ),
				
				'terNO' => array(
                    'title' => __('BUSINESS TerNO', ''),
                    'type' => 'text',
                    'description' => __('', '')
                ),
                'public_key' => array(
                    'title' => __('BUSINESS PUBLIC KEY', ''),
                    'type' => 'text',
                    'description' => __('.', '')
                ),

				'transaction_url' => array(
                    'title' => __('TRANSACTION URL', ''),
                    'type' => 'text',
                    'description' => __('', '')
                ),

				'additional_option' => array(
                    'title' => __('Additional Options', ''), 
					'default' => 'Additional Options',
                    'type' => 'title',
					
					//'type' => 'button',
					'custom_attributes' => array(
						//'onclick' => "woocommerce_addvalf();",
					),
					'css'  => 'color: #032279;text-align:center;font-weight:bold;font-size:16px;padding:10px 0;height:50px;',
					'class' => 'button-secondary addButtonId_indcashless',
					'id'       => 'woocommerce_addButtonId_indcashless',
                    'desc' => __('The following options are default.', '')
                ),
				
                'indcashless_type' => array(
                    'title' => __('Payment Type', ''),
                    'default' => 'host',
                    'type' => 'select',
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'options' => array(
                        //'card' => __('Card Payment Gateway (Direct by Curl)', ''),
                        'host' => __('Payment Gateway (Re-Direct)', '')
                    )
                ),
                'title' => array(
                    'title' => __('Title:', ''),
                    'type' => 'text',
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'description' => __('Process secure payment by Card Payment, Wallet, Net Banking, UPI & UPI Intent', ''),
                    'default' => __('Card Payment, Wallet, Net Banking, UPI & UPI Intent', '')
                ),
				'logo' => array(
                    'title' => __('Display Icon:', ''),
                    'type' => 'Checkbox', 
						'class' => 'ao1_indcashless dispIcon1_indcashless hide',
						'css' => 'display:none;',
                    'description' => __('This controls the title which the user sees during checkout.', ''),
                    'default' => __('indcashless', '')
                ),
                'description' => array(
                    'title' => __('Description:', ''),
                    'type' => 'textarea', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'description' => __('This controls the description which the user sees during checkout.', ''),
                    'default' => __('Pay  Credit card  through indcashless Secure Servers.', '')
                ),
				'status_completed' => array(
                    'title' => __('If Completed/Successfull/Test Transaction', ''),
                    'default' => 'completed',
                    'type' => 'select', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'options' => array(
                        'pending' => __('Pending payment', ''),
                        'processing' => __('Processing', ''),
                        'on-hold' => __('On hold', ''),
                        'completed' => __('Completed', ''),
                        'cancelled' => __('Cancelled', ''),
                        'refunded' => __('Refunded', ''),
                        'failed' => __('Failed', '')
                    )
                ),
                'status_cancelled' => array(
                    'title' => __('If Cancelled/Failed', ''),
                    'default' => 'cancelled',
                    'type' => 'select', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'options' => array(
                        'pending' => __('Pending payment', ''),
                        'processing' => __('Processing', ''),
                        'on-hold' => __('On hold', ''),
                        'completed' => __('Completed', ''),
                        'cancelled' => __('Cancelled', ''),
                        'refunded' => __('Refunded', ''),
                        'failed' => __('Failed', '')
                    )
                ),
                'status_pending' => array(
                    'title' => __('If Any error/ No Response', ''),
                    'default' => 'failed',
                    'type' => 'select', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'options' => array(
                        'pending' => __('Pending payment', ''),
                        'processing' => __('Processing', ''),
                        'on-hold' => __('On hold', ''),
                        'completed' => __('Completed', ''),
                        'cancelled' => __('Cancelled', ''),
                        'refunded' => __('Refunded', ''),
                        'failed' => __('Failed', '')
                    )
                ),
				'checkout_language' => array(
                    'title' => __('Checkout Language', ''),
                    'default' => 'en',
                    'type' => 'select', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'options' => array(
                        'en' => __('English', ''),'af' => __('Afrikaans', ''),'sq' => __('Albanian', ''),'am' => __('Amharic', ''),'ar' => __('Arabic', ''),'hy' => __('Armenian', ''),'az' => __('Azerbaijani', ''),'eu' => __('Basque', ''),'be' => __('Belarusian', ''),'bn' => __('Bengali', ''),'bs' => __('Bosnian', ''),'bg' => __('Bulgarian', ''),'ca' => __('Catalan', ''),'ceb' => __('Cebuano', ''),'ny' => __('Chichewa', ''),'zh-CN' => __('Chinese (Simplified)', ''),'zh-TW' => __('Chinese (Traditional)', ''),'co' => __('Corsican', ''),'hr' => __('Croatian', ''),'cs' => __('Czech', ''),'da' => __('Danish', ''),'nl' => __('Dutch', ''),'eo' => __('Esperanto', ''),'et' => __('Estonian', ''),'tl' => __('Filipino', ''),'fi' => __('Finnish', ''),'fr' => __('French', ''),'fy' => __('Frisian', ''),'gl' => __('Galician', ''),'ka' => __('Georgian', ''),'de' => __('German', ''),'el' => __('Greek', ''),'gu' => __('Gujarati', ''),'ht' => __('Haitian Creole', ''),'ha' => __('Hausa', ''),'haw' => __('Hawaiian', ''),'iw' => __('Hebrew', ''),'hi' => __('Hindi', ''),'hmn' => __('Hmong', ''),'hu' => __('Hungarian', ''),'is' => __('Icelandic', ''),'ig' => __('Igbo', ''),'id' => __('Indonesian', ''),'ga' => __('Irish', ''),'it' => __('Italian', ''),'ja' => __('Japanese', ''),'jw' => __('Javanese', ''),'kn' => __('Kannada', ''),'kk' => __('Kazakh', ''),'km' => __('Khmer', ''),'rw' => __('Kinyarwanda', ''),'ko' => __('Korean', ''),'ku' => __('Kurdish (Kurmanji)', ''),'ky' => __('Kyrgyz', ''),'lo' => __('Lao', ''),'la' => __('Latin', ''),'lv' => __('Latvian', ''),'lt' => __('Lithuanian', ''),'lb' => __('Luxembourgish', ''),'mk' => __('Macedonian', ''),'mg' => __('Malagasy', ''),'ms' => __('Malay', ''),'ml' => __('Malayalam', ''),'mt' => __('Maltese', ''),'mi' => __('Maori', ''),'mr' => __('Marathi', ''),'mn' => __('Mongolian', ''),'my' => __('Myanmar (Burmese)', ''),'ne' => __('Nepali', ''),'no' => __('Norwegian', ''),'or' => __('Odia (Oriya)', ''),'ps' => __('Pashto', ''),'fa' => __('Persian', ''),'pl' => __('Polish', ''),'pt' => __('Portuguese', ''),'pa' => __('Punjabi', ''),'ro' => __('Romanian', ''),'ru' => __('Russian', ''),'sm' => __('Samoan', ''),'gd' => __('Scots Gaelic', ''),'sr' => __('Serbian', ''),'st' => __('Sesotho', ''),'sn' => __('Shona', ''),'sd' => __('Sindhi', ''),'si' => __('Sinhala', ''),'sk' => __('Slovak', ''),'sl' => __('Slovenian', ''),'so' => __('Somali', ''),'es' => __('Spanish', ''),'su' => __('Sundanese', ''),'sw' => __('Swahili', ''),'sv' => __('Swedish', ''),'tg' => __('Tajik', ''),'ta' => __('Tamil', ''),'tt' => __('Tatar', ''),'te' => __('Telugu', ''),'th' => __('Thai', ''),'tr' => __('Turkish', ''),'tk' => __('Turkmen', ''),'uk' => __('Ukrainian', ''),'ur' => __('Urdu', ''),'ug' => __('Uyghur', ''),'uz' => __('Uzbek', ''),'vi' => __('Vietnamese', ''),'cy' => __('Welsh', ''),'xh' => __('Xhosa', ''),'yi' => __('Yiddish', ''),'yo' => __('Yoruba', ''),'zu' => __('Zulu', '')
                    )
                ),
				'additional_value' => array(
                    'title' => __('Additional Value', ''),
                    'type' => 'textarea', 
						'class' => 'ao1_indcashless hide',
						'css' => 'display:none;',
                    'description' => __('', '')
                )
            );
        }
        /**
         * Admin Panel Options
         * - Options for bits like 'title' and availability on a country-by-country basis
         **/
        public function admin_options()
        {
            echo '<h3>' . __('IndCashLess Payment Gateway', '') . '</h3>';
            echo '<p>' . __('IndCashLess is most popular payment gateway for online shopping') . '</p>';
            echo '<table class="form-table">';
            $this->generate_settings_html();
            echo '</table>';
        }
        public function validate_fields()
        {
            global $woocommerce;
            if ($this->indcashless_type == 'card') {
                
                $billing_creditcard_indcashless = str_replace(' ', '', $_POST['billing_creditcard_indcashless']);
                if (!WC_E_CHECK_CARD_indcashless::e_valid_card_number($billing_creditcard_indcashless)) {
                    wc_add_notice(__('Credit card number you entered is invalid.', 'woocommerce'), 'error');
                }
               
                if (!WC_E_CHECK_CARD_indcashless::e_valid_expiry($_POST['billing_expdatemonth_indcashless'], $_POST['billing_expdateyear_indcashless'])) {
                    wc_add_notice(__('Card expiration date is not valid.', 'woocommerce'), 'error');
                }
                if (!WC_E_CHECK_CARD_indcashless::e_valid_cvv_number($_POST['billing_ccvnumber_indcashless'])) {
                    wc_add_notice(__('Card verification number (CVV) is not valid. You can find this number on your credit card.', 'woocommerce'), 'error');
                }
            }
        }
        
        
        public function payment_scripts() {
            
			 if ($this->indcashless_type == 'card') {
					 wp_enqueue_script( 'woocommerce_indcashless_custom',plugins_url( '/assets/js/custom.js', __FILE__ ), array( 'jquery' ) );
			 }
			 
			  wp_enqueue_style( 'woocommerce_indcashless_custom',plugins_url( '/assets/style.css', __FILE__ ), true );
        }
        
        
        /**
         *  There are no payment fields for indcashless, but we want to show the description if set.
         **/
        function payment_fields()
        { 
			if ($this->logo == 'yes' || $this->settings['logo'] == 'yes') { /* ?>
					<img class='icon_indcashless' src='<?php echo woocommerce_plugin_url_indcashless;?>/img/visamastjcb.png' >
			<?php */
			}
		?>
		  
			<?php
			 if ($this->description){
				echo $description ="<div class='indcashless_description' >".wpautop(wptexturize($this->description))."</div>";
			 }
			?>
		 
		
		
		<?php
		
            if ($this->indcashless_type == 'host') {
                //if ($this->description) echo wpautop(wptexturize($this->description));
            } else {
                $billing_creditcard_indcashless = isset($_REQUEST['billing_creditcard_indcashless']) ? esc_attr($_REQUEST['billing_creditcard_indcashless']) : '';
		?>
       <p class="form-row validate-required" style="margin:15px 0 0 0;">
            <?php
                $card_number_field_placeholder = __('Card Number', 'woocommerce');
?>            
            <label><?php
                _e('Card Number', 'woocommerce');
?> <span class="required">*</span></label>
            <input class="input-text check_creditcard" type="text" size="19" maxlength="19" name="billing_creditcard_indcashless" value="<?php
                echo $billing_creditcard_indcashless;
?>" placeholder="<?php   echo $card_number_field_placeholder; ?>"  />



        </p>         
          
        <div class="clear"></div>
        <p class="form-row form-row-first">
            <label><?php
                _e('Expiration Date', 'woocommerce');
?> <span class="required">*</span></label>
            <select name="billing_expdatemonth_indcashless">
                <option value=1>01</option>
                <option value=2>02</option>
                <option value=3>03</option>
                <option value=4>04</option>
                <option value=5>05</option>
                <option value=6>06</option>
                <option value=7>07</option>
                <option value=8>08</option>
                <option value=9>09</option>
                <option value=10>10</option>
                <option value=11>11</option>
                <option value=12>12</option>
            </select>
            <select name="billing_expdateyear_indcashless">
            <?php
                $today = (int) date('Y', time());
                for ($i = 0; $i < 12; $i++) {
?>
               <option value="<?php
                    echo $today;
?>"><?php
                    echo $today;
?></option>
            <?php
                    $today++;
                }
?>
           </select>            
        </p>
        <div class="clear"></div>
        <p class="form-row form-row-first validate-required">
            <?php
                $cvv_field_placeholder = __('Card Verification Number (CVV)', 'woocommerce');
?>
           <label><?php
                _e('Card Verification Number (CVV)', 'woocommerce');
?> <span class="required">*</span></label>
            <input class="input-text" type="text" size="4" maxlength="4" name="billing_ccvnumber_indcashless" value="" placeholder="<?php
                echo $cvv_field_placeholder;
?>" />
        </p>





      
        

<div class="clear"></div>
        
        <?php
            }
        }
        /**
         * Receipt Page
         **/
        function receipt_page($order)
        {
            if ($this->indcashless_type == 'host') {
                echo '<p>' . __('Thank you for your order, please click the button below to pay with indcashless.', '') . '</p>';
                echo $this->generate_indcashless_form($order);
            }
        }
        /**
         * Process the payment and return the result
         **/
        function process_payment($order_id)
        {
            $order = new WC_Order($order_id);
            if ($this->indcashless_type == 'card') {
                $order_id = $order_id;
                global $woocommerce;
                $items = $woocommerce->cart->get_cart();
                foreach ($items as $item => $values) {
                    $_product        = wc_get_product($values['data']->get_id());
                    $product_title[] = $_product->get_title();
                }
                $product_title              = implode(',', $product_title);
				
				
				$products = $order->get_items();
				$product_title = "";
				if ( is_array( $products ) && count( $products ) > 0 ) {
					$product = current( $products );
					$product_title = $product->get_name();
				}
				
				
                $the_currency               = get_woocommerce_currency();
                $the_order_total            = @$order->order_total;
				
                $gateway_url                =  $this->transaction_url;
				
                $curlPost                   = array();
                //<!--Replace of 3 very important parameters * your product API code -->
                $curlPost["checkout_language"]      = $this->checkout_language; // language converter  
                $curlPost["public_key"]      = $this->public_key; // BUSINESS PUBLIC KEY 
                $curlPost["terNO"]       = $this->terNO; // BUSINESS TerNO 
                //<!--default (fixed) value * default -->
                $curlPost["integration-type"]       = "s2s";
                $curlPost["bill_ip"]      = ($_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR']);
                $curlPost["action"]         = "product";
				$curlPost["source"]         = "Curl-Direct (WV " . WOOCOMMERCE_VERSION . ")";
                //<!--product bill_amt,bill_currency and product name * by cart total amount -->
                $curlPost["bill_amt"]          = $the_order_total;
                $curlPost["bill_currency"]           = $the_currency;
                $curlPost["product_name"]   = $product_title;
                //<!--billing details of .* customer -->
				$curlPost["fullname"] = $order->billing_first_name. " " .$order->billing_last_name;
                $curlPost["bill_email"]          = $order->billing_email;
                $curlPost["bill_address"]  = $order->billing_address_1;
                $curlPost["bill_street_2"]  = $order->billing_address_2;
                $curlPost["bill_city"]      = $order->billing_city;
                $curlPost["bill_state"]     = $order->billing_state;
				$country=$order->get_billing_country();
				
				$billing_phone=$order->billing_phone;
				if(empty($billing_phone)){$billing_phone="9".rand(100000000,999999999);}
                
				$curlPost["bill_country"]   = $country;
                $curlPost["bill_zip"]       = $order->billing_postcode;
                $curlPost["bill_phone"]     = $billing_phone;
                $curlPost["reference"]       = $order_id;


				//$curlPost["sctest"]     		= "22";
				$curlPost["webhook_url"]     = $this->webhook_url;
				$curlPost["return_url"]    = $this->get_return_url( $order );
				//$curlPost["error_url"]      = site_url() ."/cart/?cancel_order=true&order=wc_order_&order_id=".$order_id."&redirect&_wpnonce=";
                
				//<!--card details of .* customer -->
                $curlPost["ccno"]           = $_POST['billing_creditcard_indcashless'];
                $curlPost["ccvv"]           = $_POST['billing_ccvnumber_indcashless'];
                $curlPost["month"]          = $_POST['billing_expdatemonth_indcashless'];
                $curlPost["year"]           = $_POST['billing_expdateyear_indcashless'];
                //$curlPost["notes"]="Remark for transaction";
				
				
				
				$curlPost["source"]           = "Curl-Direct (WV " . WOOCOMMERCE_VERSION . ")";
				
				$protocol = isset($_SERVER["HTTPS"])?'https://':'http://';
				$source_url=$protocol.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
	
				$curlPost["source_url"]           = (isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:$source_url);
                
				$additional_value = json_decode( $this->additional_value, true );
				
				if (($additional_value) && is_array( $additional_value ) ) {
					$curlPost=array_merge($curlPost, $additional_value);
				}
				
				$protocol                   = isset($_SERVER["HTTPS"]) ? 'https://' : 'http://';
                $referer                    = $protocol . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
                $curl_cookie                = "";
                $curl                       = curl_init();
                curl_setopt($curl, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_1_0);
                curl_setopt($curl, CURLOPT_URL, $gateway_url);
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($curl, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
                curl_setopt($curl, CURLOPT_REFERER, $referer);
                curl_setopt($curl, CURLOPT_POST, 1);
                curl_setopt($curl, CURLOPT_POSTFIELDS, $curlPost);
                curl_setopt($curl, CURLOPT_TIMEOUT, 30);
                curl_setopt($curl, CURLOPT_HEADER, 0);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($curl, CURLOPT_COOKIE, $curl_cookie);
                $response = curl_exec($curl);
				curl_close($curl);
                $results  = json_decode($response, true);
				
				if ( $results['response']['code'] == '200' ) {
					$results = json_decode( $results['body'], true );
				}
				
				if (version_compare(WOOCOMMERCE_VERSION, '2.0.0', '>=')) {  //old version 
					
				} else { // latest version 
					
				}
				
                $status   = $results["status"];
                $order_status   = $results["order_status"];
				
                $response_encode =  json_encode( $results , true) . " || " . $response ; 
				
				//error extractor
				$error="";
				if (isset( $results['Error'] ) || isset( $results['error'] ) || isset( $results['reason'] ) ) {
					
					if ( isset( $results['reason'] ) ){
						$error.=$results['reason']." <br/> ";
					}
					if ( isset( $results['Error'] ) ){
						$error.=$results['Error']." <br/> ";
					}
					if ( isset( $results['error'] ) ){
						$error.=$results['error']." <br/> ";
					}
					if ( isset( $results['descriptor'] ) && $results['descriptor'] && !$results['descriptor']=='N/A' ){
						$error.="Transaction Descriptor : ".$results['descriptor'];
					}
					//$error.=$response." | ";
					
					update_post_meta( $order_id, 'error', $error );
				}
				
                
               
              
                
           if(isset($results["status"]))
           {
             update_post_meta( $order_id, 'payment_amount', $results['amt'] );
            update_post_meta( $order_id, 'payment_currency', $results['bill_currency'] );
            update_post_meta( $order_id, 'payment_date', $results['tdate'] );
            update_post_meta( $order_id, 'payment_descriptor', $results['descriptor'] );
            update_post_meta( $order_id, 'payment_status', $results["status"] );
            update_post_meta( $order_id, 'transID', $results['transID'] );
            
            
            $order->add_order_note(__('<button id="'.$results['transID'].'" api="'.$results['public_key'].'" name="current-status" class="button-primary woocommerce-validate-current-status-indcashless" type="button" value="Validate Current Status.">Validate Current Status.</button>', ''));
            
           }
                 
                 
                 
             
                 
                
                
                if ($order_status == 1 || $order_status == 9) 
				{  // 1:Approved/Success,9:Test Transaction
                    // Payment successful
					
                    $order->add_order_note(__('indcashless  complete payment.', ''));
                    $order->payment_complete();
                    $order->update_status($this->status_completed);
                    // this is important part for empty cart
                    $woocommerce->cart->empty_cart();
                    // Redirect to thank you page
                    return array(
                        'result' => 'success',
                        'redirect' => $this->get_return_url($order)
                    );
                } else if ($order_status == 2 || $order_status == 22 || $order_status == 23)
				{ 	// 2:Declined/Failed, 22:Expired, 23:Cancelled
               
                    
					$reason="";
					if ( isset( $results['reason'] ) ){
						$reason.=$results['reason']." ";
					}
					
                     wc_add_notice( sprintf( __($reason.' <a href="%s" class="button alt">Return to Checkout Page</a>'), get_permalink( get_option('woocommerce_checkout_page_id') ) ), 'error' );
                    
                    
                    $order->add_order_note( $status. ':- ' . $reason . "log: " . $response_encode );
					
                    $order->update_status($this->status_cancelled);
                } else {
                    //transaction error or pending 
                    //if($error
						
						if ( isset( $results['reason'] ) ){
							$error .= $results['reason']." ";
						}
					
						wc_add_notice( sprintf( __($error.' <a href="%s" class="button alt">Return to Checkout Page</a>'), get_permalink( get_option('woocommerce_checkout_page_id') ) ), 'error' );
						$order->add_order_note('cError: ' . $error . "log: " . $response_encode );
						$order->update_status($this->status_pending);
					//}
                    
                }
            }
            update_post_meta($order_id, '_post_data', $_POST);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url(true)
            );
        }
        
        
       
        
        /**
         * Check for valid indcashless server callback
         **/
        function check_indcashless_response()
        {
            global $woocommerce;
            $msg['class']   = 'error';
            $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
            $json_response  = $_POST;
            
              $order_id       = $json_response['reference'];
            $order_id = explode('_', $order_id);
            $order_id = $order_id[0];
            
            
            
            $check_transID = get_post_meta( $order_id, 'transID', true );
           if(isset($json_response["status"]))
           {
             update_post_meta( $order_id, 'payment_amount', $json_response['amt'] );
            update_post_meta( $order_id, 'payment_currency', $json_response['bill_currency'] );
            update_post_meta( $order_id, 'payment_date', $json_response['tdate'] );
            update_post_meta( $order_id, 'payment_descriptor', $json_response['descriptor'] );
            update_post_meta( $order_id, 'payment_status', $json_response["status"] );
            update_post_meta( $order_id, 'transID', $json_response['transID'] );
            
           }
            
            
            $get_settings=get_option( 'woocommerce_indcashless_settings', true );
  
          
            if (isset($json_response['transID'])) {
                
                if ($order_id != '') {
                    try {
                        $order        = new WC_Order($order_id);
                        if(empty( $check_transID)){
                        $order->add_order_note(__('<button id="'.$json_response['transID'].'" api="'.$get_settings['public_key'].'" name="current-status" class="button-primary woocommerce-validate-current-status-indcashless" type="button" value="Validate Current Status!">Validate Current Status!</button>', ''));
                        }
                        $status_name = $json_response['status'];
                        $order_status = $json_response['order_status'];
                        if ($order->get_status() !== 'Completed') {
                            if ($order_status == 1 || $order_status == 9)
							{  // 1:Approved/Success,9:Test Transaction
						
                                $transauthorised = true;
                                $msg['message']  = "Thank you for shopping with us. Your account has been charged and your transaction is successful. We will be shipping your order to you soon.";
                                $msg['class']    = 'success';
                                if ($order->status != 'processing') {
                                    $order->payment_complete();
                                    $order->update_status($this->status_completed);
                                       if(empty( $check_transID)){
                                    $order->add_order_note('indcashless payment successful<br/>Transaction ID: ' . $json_response['transID']);
                                       }
                                    $woocommerce->cart->empty_cart();
                                }
                            } else if($order_status == 2 || $order_status == 22 || $order_status == 23)
							{ // 2:Declined/Failed, 22:Expired, 23:Cancelled
                                $msg['class']   = 'error';
                                $msg['message'] = " We are waiting for your order status from the bank-Transaction pending";
                                $order->update_status($this->status_cancelled);
                            } else {
                                $msg['class']   = 'error';
                                $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
                                $order->update_status($this->status_pending);
                            }
                            /* if($transauthorised==false){
                            $order -> update_status('failed');
                            $order -> add_order_note('Failed');
                            $order -> add_order_note($this->msg['message']);
                            }*/
                        }
                    }
                    catch (Exception $e) {
                        $msg['class']   = 'error';
                        $msg['message'] = "Thank you for shopping with us. However, the transaction has been declined.";
                    }
                }
            }
            if (function_exists('wc_add_notice')) {
                wc_add_notice($msg['message'], $msg['class']);
            } else {
                if ($msg['class'] == 'success') {
                    $woocommerce->add_message($msg['message']);
                } else {
                    $woocommerce->add_error($msg['message']);
                }
                $woocommerce->set_messages();
            }
           
            $redirect_url = $this->get_return_url($order);
            wp_redirect($redirect_url);
            exit;
        }
        /*
      
        
        /**
         * Generate  button link
         **/
        public function generate_indcashless_form($order_id)
        {
            global $woocommerce;
            $order     = new WC_Order($order_id);
            $order_id  = $order_id;
            $post_data = get_post_meta($order_id, '_post_data', true);
            update_post_meta($order_id, '_post_data', array());
            $the_currency    = get_woocommerce_currency();
            $the_order_total = @$order->order_total;
            if ($this->indcashless_type == 'host') {
                $form = '';
                wc_enqueue_js('
                    $.blockUI({
                        message: "<h2>Please wait while we process your request</h2><p>Since this may take a few seconds, please do not close/refresh this window.</p>",
                        baseZ: 99999,
                        overlayCSS:
                        {
                            background: "red",
                            opacity: 0.6
                        },
                        css: {
                            padding:        "20px",
                            zindex:         "9999999",
                            textAlign:      "center",
                            color:          "#555",
                            border:         "3px solid #aaa",
                            backgroundColor:"#fff",
                            cursor:         "wait",
                            lineHeight:     "24px",
                        }
                    });
                jQuery("#submit_indcashless_payment_form").click();
                ');
                $targetto = 'target="_top"';
                $items    = $woocommerce->cart->get_cart();
                foreach ($items as $item => $values) {
                    $_product        = wc_get_product($values['data']->get_id());
                    $product_title[] = $_product->get_title();
                }
                $product_title      = implode(',', $product_title);
				
				
				$products = $order->get_items();
				$product_title = "";
				if ( is_array( $products ) && count( $products ) > 0 ) {
					$product = current( $products );
					$product_title = $product->get_name();
				}
				
				
                $indcashless_args_array   = array();
                $indcashless_args_array[] = "<input type='hidden' name='checkout_language' value='" . $this->checkout_language . "'/>";
                $indcashless_args_array[] = "<input type='hidden' name='public_key' value='" . $this->public_key . "'/>";
                $indcashless_args_array[] = "<input type='hidden' name='terNO' value='" . $this->terNO . "'/>";
                $indcashless_args_array[] = '<input type="hidden" name="integration-type" value="Encode-Checkout"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_ip" value="'.($_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR']).'"/>';
                $indcashless_args_array[] = '<input type="hidden" name="action" value="product"/>'; 
				$indcashless_args_array[] = '<input type="hidden" name="source" value="Host-Re-Direct (WV ' . WOOCOMMERCE_VERSION . ')"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_amt" value="' . $the_order_total . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_currency" value="' . $the_currency . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="product_name" value="' . $product_title . ' "/>';
				$indcashless_args_array[] = '<input type="hidden" name="fullname" value="' . @$order->billing_first_name ." " . @$order->billing_last_name. '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_email" value="' . @$order->billing_email . '"/>';
				
				$bill_address = @$order->billing_address_1 . " " .@$order->billing_address_2;
				
                $indcashless_args_array[] = '<input type="hidden" name="bill_address" value="' . @$bill_address . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_city" value="' . @$order->billing_city . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_state" value="' . @$order->billing_state . '"/>';
				$country=$order->get_billing_country();
				$billing_phone=$order->billing_phone;
				if(empty($billing_phone)){$billing_phone="8".rand(100000000,999999999);}
				$indcashless_args_array[] = '<input type="hidden" name="bill_country" value="' .$country. '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_zip" value="' . @$order->billing_postcode . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="bill_phone" value="' . $billing_phone . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="reference" value="' . $order_id . '"/>';
               
			   $indcashless_args_array[] = '<input type="hidden" name="webhook_url" value="' . $this->webhook_url . '"/>';
                $indcashless_args_array[] = '<input type="hidden" name="return_url" value="' . $this->get_return_url( $order ) . '"/>';
               // $indcashless_args_array[] = '<input type="hidden" name="error_url" value="' . site_url() ."/cart/?cancel_order=true&order=wc_order_&order_id=".$order_id."&redirect&_wpnonce=" . '"/>';
				
				$protocol = isset($_SERVER["HTTPS"])?'https://':'http://';
				$source_url=$protocol.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
				
				$indcashless_args_array[] = '<input type="hidden" name="source_url" value="' . (isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:$source_url) . '"/>';
				
				
				
				$additional_value = json_decode( $this->additional_value, true );
				if (($additional_value) && is_array( $additional_value ) ) {
					foreach($additional_value as $key=>$value){
						$indcashless_args_array[] = '<input type="hidden" name="'.$key.'" value="'.$value.'"/>';
					}
				}
				
				$host_url = $this->transaction_url;
				
                $form .= '<form action="'. $host_url .'" method="post" id="indcashless_payment_form"  ' . $targetto . '>
                ' . implode('', $indcashless_args_array) . '
                <!-- Button Fallback -->
                <div class="payment_buttons">
                <input type="submit" class="button alt" id="submit_indcashless_payment_form" value="' . __('Pay via indcashless', 'woocommerce') . '" /> <a class="button cancel" href="' . esc_url($order->get_cancel_order_url()) . '">' . __('Cancel order &amp; restore cart', 'woocommerce') . '</a>
                </div>
                <script type="text/javascript">
                jQuery(".payment_buttons").hide();
                </script>
                </form>';
                return $form;
            }
        }
    }
    
    
    /**
     * Add the Gateway to WooCommerce
     **/
    function woocommerce_add_indcashless_gateway($methods)
    {
        $methods[] = 'WC_indcashless';
        return $methods;
    }
    add_filter('woocommerce_payment_gateways', 'woocommerce_add_indcashless_gateway');
}


 function admin_indcashless_load_scripts( $hook ) {
	$get_settings=get_option( 'woocommerce_indcashless_settings', true );
   echo "<script>
                var indcashless_public_key='{$get_settings['public_key']}';
        </script>";
		
    //wp_enqueue_script( 'my_custom_script', plugin_dir_url( __FILE__ ) . 'assets/js/indcashless_admin_custom.js', array(), '1.0' ); 
	
	 wp_enqueue_script( 'my-plugin-script-indcashless', plugin_dir_url( __FILE__ ) . 'assets/js/indcashless_admin_custom.js'); 
}

    

add_action( 'admin_enqueue_scripts', 'admin_indcashless_load_scripts' );


add_action('wp_ajax_check_indcashless_transaction_status', 'check_indcashless_transaction_status');

function check_indcashless_transaction_status(){


	$validateurl=get_option( 'woocommerce_indcashless_settings', true );

	$transID=$_POST['tra_id'];
	//$url=$validateurl['validate_url']."?transID=".$transID;
	$url=implode('/', explode('/', $validateurl['transaction_url'], -1))."/fetch_trnsStatus"."?transID=".$transID."&public_key=".$validateurl['public_key'];
		
		$setPost=array();
		$setPost['transID'] 	=  $transID;
		$setPost['public_key'] 	=  $validateurl['public_key'];
		
	
     	$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_POST,1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $setPost);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false); 
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST, false);
		$response = curl_exec($ch);
		curl_close($ch);
		$json_response = json_decode($response,true);
		
		$htmlresponse="";
		foreach($json_response as $key=>$data)
		{
		    
		  	$htmlresponse.="<br><b>".$key.":</b>".$data;  
		    
		    
		}
	echo $htmlresponse;
	exit;


}



?>