<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}
# indcashless_logger() is defined in indcashless/lib/indcashless.php
require_once __DIR__  ."/indcashless/lib/indcashless.php";

function indcashless_MetaData()
{
    return array(
        'DisplayName' => 'India Cash Less Payment Gateway',
        'APIVersion' => '2.3',
        'DisableLocalCredtCardInput' => true,
        'TokenisedStorage' => false,
    );
}


function indcashless_config()
{
    return array(
        'FriendlyName' => array(
            'Type' => 'System',
            'Value' => 'Credit Card & Crypto eWallet',
        ),		
        'indcashless_terNO' => array(
            'FriendlyName' => 'BUSINESS TerNO *(mandatory)',
            'Type' => 'text',
            'Size' => '250',
            'Default' => '',
            'Description' => 'BUSINESS TerNO',
        ),
        'indcashless_public_key' => array(
            'FriendlyName' => 'BUSINESS PUBLIC KEY *(mandatory)',
            'Type' => 'text',
            'Size' => '250',
            'Default' => '',
            'Description' => '',
        ),
		'indcashless_transaction_url' => array(
            'FriendlyName' => 'TRANSACTION URL',
            'Type' => 'text',
            'Size' => '450',
            'Default' => '',
            'Description' => 'TRANSACTION URL from Gateway',
        ),
		'indcashless_checkout_language' => array(
			'FriendlyName' => 'Checkout Language',
			'Type' => 'dropdown',
			'Size' => '250',
			'Options' => array(
				'en' => 'English','af' => 'Afrikaans','sq' => 'Albanian','am' => 'Amharic','ar' => 'Arabic','hy' => 'Armenian','az' => 'Azerbaijani','eu' => 'Basque','be' => 'Belarusian','bn' => 'Bengali','bs' => 'Bosnian','bg' => 'Bulgarian','ca' => 'Catalan','ceb' => 'Cebuano','ny' => 'Chichewa','zh-CN' => 'Chinese (Simplified)','zh-TW' => 'Chinese (Traditional)','co' => 'Corsican','hr' => 'Croatian','cs' => 'Czech','da' => 'Danish','nl' => 'Dutch','eo' => 'Esperanto','et' => 'Estonian','tl' => 'Filipino','fi' => 'Finnish','fr' => 'French','fy' => 'Frisian','gl' => 'Galician','ka' => 'Georgian','de' => 'German','el' => 'Greek','gu' => 'Gujarati','ht' => 'Haitian Creole','ha' => 'Hausa','haw' => 'Hawaiian','iw' => 'Hebrew','hi' => 'Hindi','hmn' => 'Hmong','hu' => 'Hungarian','is' => 'Icelandic','ig' => 'Igbo','id' => 'Indonesian','ga' => 'Irish','it' => 'Italian','ja' => 'Japanese','jw' => 'Javanese','kn' => 'Kannada','kk' => 'Kazakh','km' => 'Khmer','rw' => 'Kinyarwanda','ko' => 'Korean','ku' => 'Kurdish (Kurmanji)','ky' => 'Kyrgyz','lo' => 'Lao','la' => 'Latin','lv' => 'Latvian','lt' => 'Lithuanian','lb' => 'Luxembourgish','mk' => 'Macedonian','mg' => 'Malagasy','ms' => 'Malay','ml' => 'Malayalam','mt' => 'Maltese','mi' => 'Maori','mr' => 'Marathi','mn' => 'Mongolian','my' => 'Myanmar (Burmese)','ne' => 'Nepali','no' => 'Norwegian','or' => 'Odia (Oriya)','ps' => 'Pashto','fa' => 'Persian','pl' => 'Polish','pt' => 'Portuguese','pa' => 'Punjabi','ro' => 'Romanian','ru' => 'Russian','sm' => 'Samoan','gd' => 'Scots Gaelic','sr' => 'Serbian','st' => 'Sesotho','sn' => 'Shona','sd' => 'Sindhi','si' => 'Sinhala','sk' => 'Slovak','sl' => 'Slovenian','so' => 'Somali','es' => 'Spanish','su' => 'Sundanese','sw' => 'Swahili','sv' => 'Swedish','tg' => 'Tajik','ta' => 'Tamil','tt' => 'Tatar','te' => 'Telugu','th' => 'Thai','tr' => 'Turkish','tk' => 'Turkmen','uk' => 'Ukrainian','ur' => 'Urdu','ug' => 'Uyghur','uz' => 'Uzbek','vi' => 'Vietnamese','cy' => 'Welsh','xh' => 'Xhosa','yi' => 'Yiddish','yo' => 'Yoruba','zu' => 'Zulu',
			),
			'Default' => 'en',
			'Description' => 'Checkout Language - automatically switch checkout language on payment getaway page',
		),
		
       
    );
}


function indcashless_link($params)
{
    // Gateway Configuration Parameters
    $terNO = $params['indcashless_terNO'];
    $public_key = $params['indcashless_public_key'];
	
	$transaction_url = $params['indcashless_transaction_url'];
	
	$checkout_language = $params['indcashless_checkout_language'];
	
    // Invoice Parameters
    $invoiceId = $params['invoiceid'];
    $amount = $params['amount'];
    $currencyCode = $params['currency'];


    // System Parameters
    $companyName = $params['companyname'];
    $systemUrl = $params['systemurl'];
    $returnUrl = $params['returnurl'];
    $langPayNow = $params['langpaynow'];
    $moduleDisplayName = $params['name'];
    $moduleName = $params['paymentmethod'];
    $whmcsVersion = $params['whmcsVersion'];

    $postfields = array();
	$postfields['terNO'] 	= $terNO;
	$postfields['public_key'] 	= $public_key;
	
	$postfields['action'] 		= "product";
	$postfields['integration-type'] 	= "Encode-Checkout"; // curl	Encode-Checkout
	$postfields['bill_ip'] 	= ($_SERVER['HTTP_X_FORWARDED_FOR']?$_SERVER['HTTP_X_FORWARDED_FOR']:$_SERVER['REMOTE_ADDR']);
	$postfields['source'] 		= " WHMCS Re-Direct indcashless V-".$whmcsVersion;

	

	$reference				= time()."-".$invoiceId;
	$postfields['reference'] = $reference;
	$postfields['bill_amt'] = $amount;
	$postfields['bill_currency'] 	= $currencyCode;
    
	$postfields['fullname'] = $params['clientdetails']['firstname'].' '.$params['clientdetails']['lastname'];
	
	$bill_address = $params['clientdetails']['address1'] . " " .$params['clientdetails']['address2'];
	
	$postfields["bill_address"]  	= $bill_address;
	$postfields["bill_city"]		= $params['clientdetails']['city'];
	$postfields["bill_state"]		= $params['clientdetails']['state'];
	$postfields["bill_country"]		= $params['clientdetails']['country'];
	$postfields["bill_zip"]			= $params['clientdetails']['postcode'];
	$postfields['bill_email']		= $params['clientdetails']['email'];
	$postfields['bill_phone']		= $params['clientdetails']['phonenumber'];
	$postfields['checkout_language'] = $checkout_language;
	
	$product_name='';
	$invoiceItems = indcashless_getInvoiceItems( $params['invoiceid'] );
	foreach ($invoiceItems as $item) {
		$product_name .= strip_tags($item['description']);
	}
	$postfields['product_name']		= ($product_name);
	
	$postfields['transID'] 	= $reference; 
	$postfields['api_version'] 		= 'WHMC2.2';
	
	$protocol = isset($_SERVER["HTTPS"])?'https://':'http://';
	$source_url=$protocol.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];
	$postfields['source_url'] = (isset($_SERVER['HTTP_REFERER'])?$_SERVER['HTTP_REFERER']:$source_url);
	
	$postfields['redirect_url'] = $systemUrl . 'modules/gateways/callback/' . $moduleName . '.php';
    
	$webhook_url = $systemUrl . 'modules/gateways/callback/indcashless.php?reference='.$reference;
	$postfields['webhook_url'] = $webhook_url.'&actionpram=webhook_url';
	$postfields['return_url'] = $webhook_url.'&actionpram=return_url';
	//$postfields['error_url'] = $webhook_url.'&actionpram=error_url';
	$postfields['return_url'] = $returnUrl;
	$_SESSION['return_url'] = $returnUrl;
	//$postfields['return_url'] = $returnUrl;
	//$postfields['error_url'] = $returnUrl;
	
	
	$input="";
	foreach($postfields as $key=>$value){
		$input.='<input type="hidden" name="'.$key.'" value="'.$value.'" />';
	}
	
	try{
		indcashless_logger("Creating indcashless order for $invoiceId");
		indcashless_logger("indcashless Settings are BUSINESS TerNO = $terNO | PUBLIC KEY = $public_key | TRANSACTION URL = $transaction_url | Checkout Language = $checkout_language");
		
		
		$htmlOutput = '<form method="post" action="' . $transaction_url . '">';
			$htmlOutput .= $input;
			$htmlOutput .= '<input type="submit" value="' . $langPayNow . '" />';
			$htmlOutput .= '</form>';

			return $htmlOutput;
		
		
		
	}catch(CurlException $e){
		// handle exception releted to connection to the sever
		indcashless_logger((string)$e);
		$htmlOutput = "<p style='color:red'>Sorry for inconvenience <br/>Problem while connecting indcashless please contact administrator for support</p>";
		$htmlOutput .= "<a href='$redirectUrl'>Back</a>";
		return $htmlOutput;
	}catch(ValidationException $e){
		// handle exceptions releted to response from the server.
		indcashless_logger($e->getMessage()." with ");
		indcashless_logger(print_r($e->getResponse(),true)."");
		$htmlOutput = "";
		foreach($e->getErrors() as $error )
		{
			
			if(stristr($error,"Authorization"))
				$htmlOutput .= "<p style='color:red'>Merchant Authorization Failed </p>";
			elseif(stristr($error,"phone"))
				$htmlOutput .="<p style='color:red'>Your Phone number should be a valid Indian Mobile number</p>";
			else
				$htmlOutput .="<p style='color:red'>$error</p>";
		}	
			
			return $htmlOutput;
	}catch(Exception $e)
	{ // handled common exception messages which will not caught above.
		
		indcashless_logger('Error While Creating Order : ' . $e->getMessage());
		$htmlOutput = "<p style='color:red'>Sorry for inconvenience<br/>Problem while connecting indcashless please contact administrator for support</p>";
		$htmlOutput .= "<a href='$redirectUrl'>Back</a>";
		return $htmlOutput;

	}
   return "";
}

function indcashless_getInvoiceItems($invoiceId )
{
    $invoiceHostingItems = Illuminate\Database\Capsule\Manager::table('tblinvoiceitems')
        ->where('invoiceid', $invoiceId)
        ->get();
    return json_decode(json_encode($invoiceHostingItems), true);
}



