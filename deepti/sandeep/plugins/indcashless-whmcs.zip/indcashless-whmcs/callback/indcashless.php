<?php

require_once __DIR__ . '/../../../init.php';
require_once __DIR__ . '/../../../includes/gatewayfunctions.php';
require_once __DIR__ . '/../../../includes/invoicefunctions.php';
require_once __DIR__ . '/../indcashless/lib/indcashless.php';



//indcashless_logger(print_r($_POST, true));indcashless_logger(print_r($_GET, true));

$qp=0;
if(isset($_GET['qp'])){
	$qp=1;
}
// Detect module name from filename.
$gatewayModuleName = basename(__FILE__, '.php');

// Fetch gateway configuration parameters.
$gatewayParams = getGatewayVariables($gatewayModuleName);

// Die if module is not active.
if (!$gatewayParams['type']) {
    //die("Module Not Activated");
}


$stored_pri = "";
if(isset($_SESSION['indcashless_payment_request_id']))
	$stored_pri = $_SESSION['indcashless_payment_request_id'];

if($qp){
	echo "<hr/>type=> ".$gatewayParams['type'];
	echo "<hr/>stored_pri=> ".$stored_pri;
}


try{
	
	
	$payment_status="";$transID="";$reference="";$amount="";$bill_currency="";$p=array();
				
	if($_POST){
		$p=$_POST;
		$order_status=(int)$_POST['order_status'];
		$payment_status=$_POST['status'];
		$transID=$_POST['transID'];
		$reference = $_POST['reference'];
		$amount = $_POST['bill_amt'];
		$bill_currency = $_POST['bill_currency'];
	}
	else if($_GET){
		$p=$_GET;
		$payment_status=$_GET['status'];
		$order_status=(int)$_GET['order_status'];
		$transID=$_GET['transID'];
		$reference = $_GET['reference'];
		$amount = $_GET['bill_amt'];
		$bill_currency = $_GET['bill_currency'];
	}
	$actionpram = $_REQUEST['actionpram'];
	
	if(($reference) && (strpos($reference,"-")!==false)){
		$reference = explode("-",$reference);
		$reference = $reference[1];
		indcashless_logger("Extracted order id from order_id: ".$reference);
	}
	
	if($qp){
		echo "<hr/>order_status=> ".$order_status;
		echo "<hr/>payment_status=> ".$payment_status;
		echo "<hr/>transID=> ".$transID;
		echo "<hr/>reference=> ".$reference;
	}
				
	
	if($order_status)
	{
		
		
		if($order_status == 1 || $order_status == 9)
		{  // 1:Approved/Success,9:Test Transaction
			
			
			indcashless_logger("Payment was credited with Payment ID :$transID");
			
			if($qp){
				echo "<hr/>order_id=> ".$order_id;
				echo "<hr/>gatewayParams['name']=> ".$gatewayParams['name'];
				print_r($gatewayParams);
			}
			
			//$invoiceId = checkCbInvoiceID($order_id, $gatewayParams['name']);
			
			$invoiceId=$reference;
			
			if($qp){
				echo "<hr/>invoiceId=> ".$invoiceId;
				echo "<hr/>gatewayParams['name']=> ".$gatewayParams['name'];
				print_r($gatewayParams);
			}
			
			$paymentAmount = $amount;
			$currency = getCurrency();
			indcashless_logger(print_r($currency, true));
			
			
			logTransaction($gatewayParams['name'], $array = json_decode(json_encode($p), true), $payment_status);
			
			if($qp){
				echo "<hr/>paymentAmount=> ".$paymentAmount;
				echo "<hr/>currency['code']=> ".$currency['code'];
				
				echo "<hr/>invoiceId=> ".$invoiceId;
				echo "<hr/>transID=> ".$transID;
				echo "<hr/>convertedPaymentAmount=> ".$convertedPaymentAmount;
				echo "<hr/>gatewayModuleName=> ".$gatewayModuleName;
			
			}
			
			indcashless_logger(print_r($p, true));
	
			$addInvoicePayment=addInvoicePayment(
				$invoiceId,
				$transID,
				$paymentAmount,
				0, //payment fees.
				$gatewayModuleName
			);
			
			if($qp){
				echo "<hr/>addInvoicePayment=> ";
				print_r($addInvoicePayment);
			}
			
			if(isset($_SESSION['return_url'])){
				$redirect_url =  $_SESSION['return_url'];
			}else{
				$redirect_url = $gatewayParams['systemurl'];
			}
			
			if($actionpram != 'webhook_url'){
				header("Location:$redirect_url");
			}
			exit();
			
		}
		else if($order_status == 2)
		{ // 2:Declined/Failed
			if(isset($_SESSION['return_url'])){
				$redirect_url =  $_SESSION['return_url'];
			}else{
				$redirect_url = $gatewayParams['systemurl'];
			}
			
			if($actionpram != 'webhook_url'){
				header("Location:$redirect_url");
			}
			exit();
			die();

		}					
	}
	else
	{
		indcashless_logger("Unimplemented Payment Status $payment_status");
		if($actionpram != 'webhook_url'){
			header("Location:".$gatewayParams[systemurl]);
		}
		exit();
		die();
	}

}catch(Exception $e){
	indcashless_logger("Exception Occcured during Payment Confirmation with message ".$e->getMessage());
	//exit;
	//header("Location:$gatewayParams[systemurl]");
}		



